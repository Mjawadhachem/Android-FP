package com.example.karmacart.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.karmacart.data.entity.Post
import com.example.karmacart.databinding.ItemPostBinding

class PostAdapter(
    private var items: List<Post>,
    private val onItemLongClick: (Post) -> Unit = {}
) : RecyclerView.Adapter<PostAdapter.VH>() {

    inner class VH(val b: ItemPostBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemPostBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        // Show REQUEST or DONATION with emoji
        holder.b.tvType.text = if (p.type == "REQUEST") "🆘 Request" else "🎁 Donation"
        holder.b.tvTitle.text = p.title
        holder.b.tvDesc.text = p.description
        holder.b.tvMeta.text = "${p.category} • ${p.contact}"

        holder.itemView.setOnLongClickListener {
            onItemLongClick(p)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<Post>) {
        items = newItems
        notifyDataSetChanged()
    }
}
