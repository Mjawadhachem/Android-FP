package com.example.karmacart

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.karmacart.data.database.AppDatabase
import com.example.karmacart.data.repository.PostRepository
import com.example.karmacart.databinding.ActivityMainBinding
import com.example.karmacart.ui.main.PostAdapter
import com.example.karmacart.viewmodel.PostViewModel
import com.example.karmacart.viewmodel.PostViewModelFactory
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // ViewBinding for activity_main.xml
    private lateinit var binding: ActivityMainBinding

    // Room database
    private val db by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "karmacart.db"
        ).build()
    }

    // ViewModel
    private val vm: PostViewModel by viewModels {
        PostViewModelFactory(PostRepository(db.postDao()))
    }

    // RecyclerView adapter
    private lateinit var adapter: PostAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout with ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup RecyclerView
        adapter = PostAdapter(emptyList()) { post ->
            // long press → delete
            lifecycleScope.launch {
                vm.deletePost(post)
                Snackbar.make(binding.root, "Deleted: ${post.title}", Snackbar.LENGTH_SHORT).show()
            }
        }
        binding.rvPosts.layoutManager = LinearLayoutManager(this)
        binding.rvPosts.adapter = adapter

        // Observe posts from ViewModel
        vm.posts.observe(this) { posts ->
            adapter.submit(posts)
        }

        // For now: FAB adds demo post
        binding.fabAdd.setOnClickListener {
            lifecycleScope.launch {
                vm.addPost(
                    type = "REQUEST",
                    title = "Need O+ blood at City Hospital",
                    desc = "Urgent today between 6–9pm.",
                    cat = "Blood",
                    contact = "70 123 456"
                )
            }
        }
    }
}
