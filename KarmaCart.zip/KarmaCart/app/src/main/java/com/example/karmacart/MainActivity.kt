package com.example.karmacart

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.karmacart.data.database.AppDatabase
import com.example.karmacart.data.repository.PostRepository
import com.example.karmacart.databinding.ActivityMainBinding
import com.example.karmacart.ui.main.PostAdapter
import com.example.karmacart.viewmodel.PostViewModel
import com.example.karmacart.viewmodel.PostViewModelFactory
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // ViewBinding for activity_main.xml
    private lateinit var binding: ActivityMainBinding

    // Room database instance
    private val db by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "karmacart.db"
        ).build()
    }

    // ViewModel with factory
    private val vm: PostViewModel by viewModels {
        PostViewModelFactory(PostRepository(db.postDao()))
    }

    // RecyclerView adapter
    private lateinit var adapter: PostAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate layout with ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // =======================================================
        // 1) RecyclerView setup
        // =======================================================
        adapter = PostAdapter(emptyList()) { post ->
            // Long press → delete post
            lifecycleScope.launch {
                vm.deletePost(post)
                Snackbar.make(binding.root, "Deleted: ${post.title}", Snackbar.LENGTH_SHORT).show()
            }
        }

        binding.rvPosts.layoutManager = LinearLayoutManager(this)
        binding.rvPosts.adapter = adapter

        // =======================================================
        // 2) Observe posts from ViewModel
        // =======================================================
        vm.posts.observe(this) { posts ->
            adapter.submit(posts)
        }

        // =======================================================
        // 3) Floating Action Button → Add demo post
        // =======================================================
        binding.fabAdd.setOnClickListener {
            lifecycleScope.launch {
                vm.addPost(
                    type = "REQUEST",
                    title = "Need O+ blood at City Hospital",
                    desc = "Urgent today between 6–9pm.",
                    cat = "Blood",
                    contact = "70 123 456"
                )
            }
        }

        // =======================================================
        // 4) Dashboard buttons
        // =======================================================
        setupDashboardButtons()
    }

    // =======================================================
    // DASHBOARD BUTTONS (English)
    // =======================================================
    private fun setupDashboardButtons() {

        // Request help
        binding.btnRequestHelp.setOnClickListener {
            Toast.makeText(
                this,
                "Request help (screen coming soon)",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Offer help
        binding.btnOfferHelp.setOnClickListener {
            Toast.makeText(
                this,
                "Offer help (screen coming soon)",
                Toast.LENGTH_SHORT
            ).show()
        }

        // My posts
        binding.btnMyPosts.setOnClickListener {
            Toast.makeText(
                this,
                "Showing only your posts (to implement)",
                Toast.LENGTH_SHORT
            ).show()
        }

        // All posts
        binding.btnAllPosts.setOnClickListener {
            Toast.makeText(
                this,
                "Showing all posts",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
